from __future__ import absolute_import, division, print_function
__metaclass__ = type

def get_users(module):
    return ['win_user|domain1|client.company.com']